package com.haiyisec.modules.inventorymanager.domain.service.importservice;

import org.testng.ISuite;
import org.testng.ISuiteListener;

import java.util.concurrent.atomic.AtomicInteger;

public class MonopolizeSuiteListener implements ISuiteListener {
    public static final AtomicInteger curCount = new AtomicInteger(0);
    public static BaseImportFileTest.Param curParam = null;

    @Override
    public void onFinish(ISuite suite) {
        curCount.incrementAndGet();
        if( curCount.get() < MonopolizeTest.params.length){
            curParam = MonopolizeTest.params[curCount.get()];
            suite.run();
        }
    }
}
