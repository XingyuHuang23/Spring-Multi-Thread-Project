package com.haiyisec.oa.inventorymanager.domain.service.test.test_strategy;

public enum StrategyType {
    APP,USER,CUSTOM
}
