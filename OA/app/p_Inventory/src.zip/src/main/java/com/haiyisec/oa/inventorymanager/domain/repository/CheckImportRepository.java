package com.haiyisec.oa.inventorymanager.domain.repository;

import com.haiyisec.oa.inventorymanager.domain.model.po.goods.CheckImport;
import org.zen.frame.vendor.spring.springdata.jpa.domain.repository.BaseRepository;

public interface CheckImportRepository extends BaseRepository<CheckImport, String> {


}
