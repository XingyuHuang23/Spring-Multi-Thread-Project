package com.haiyisec.oa.inventorymanager.domain.service.test;

import com.haiyisec.oa.inventorymanager.domain.model.vo.goods.HyExcelModel;
import org.zen.frame.base.domain.obj.CheckResult;

import java.util.List;

public class HyAdaption {

    public  void preDateHandler(CheckResult cr, List successDatas, List failDatas, String taskId){

    };

    public  void failHandler(List<HyExcelModel> successDatas, String taskId){

    };
    public  void successHandler(List<HyExcelModel> successDatas, String taskId){

    };
}
