package com.haiyisec.oa.inventorymanager.domain.service.test.test_strategy;

import org.zen.frame.base.domain.obj.OutResult;

public interface Strategy<ImportParams>  {

    OutResult operation(ImportParams operation);

}
