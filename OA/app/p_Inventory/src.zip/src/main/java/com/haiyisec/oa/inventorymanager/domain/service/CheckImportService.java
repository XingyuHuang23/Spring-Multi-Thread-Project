package com.haiyisec.oa.inventorymanager.domain.service;

import com.haiyisec.oa.inventorymanager.domain.model.po.goods.CheckImport;
import com.haiyisec.oa.inventorymanager.domain.repository.CheckImportRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.zen.frame.vendor.spring.springdata.jpa.domain.repository.BaseRepository;
import org.zen.frame.vendor.spring.springmvc.common.domain.service.BaseService;

@Service
public class CheckImportService extends BaseService<CheckImport> {
    @Autowired
    private CheckImportRepository checkImportRepository;

    @Override
    public BaseRepository<CheckImport, String> getDao() {
        return checkImportRepository;
    }

    public void save(CheckImport checkImport){
        checkImportRepository.save(checkImport);
    }
}
