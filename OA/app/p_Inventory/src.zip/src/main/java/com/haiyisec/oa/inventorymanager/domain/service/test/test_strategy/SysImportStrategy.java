package com.haiyisec.oa.inventorymanager.domain.service.test.test_strategy;


import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.zen.frame.base.domain.obj.OutResult;

@Slf4j
@Component
public class SysImportStrategy implements Strategy<SysImportStrategy.ImportParams> {

    @Override
    public OutResult operation(SysImportStrategy.ImportParams importParams) {
        OutResult or = new OutResult();
        or.setSuccess(false);

        if(importParams.modelTaskNum + 1 > importParams.maxTaskNum){  //校验逻辑的实现位置 if(xx>3) return false;
            or.setSuccess(true);
            or.setMsg("超过系统拥有任务数最大限制");
            return  or;
        }
        return or;
    }


    @Getter
    @Setter
    @Accessors(chain = true)
    public static class ImportParams{
        //内部类,校验参数的定义，max_num,max_task_num,max_user_task_num

        //同一model一个用户只能有一个
        private int modelTaskNum;
        private int maxTaskNum; //同一模块最多允许几个task
        private String model;
    }
}
