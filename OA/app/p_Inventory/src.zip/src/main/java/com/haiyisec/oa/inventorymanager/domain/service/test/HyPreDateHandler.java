package com.haiyisec.oa.inventorymanager.domain.service.test;

import com.haiyisec.oa.inventorymanager.domain.model.vo.goods.CheckResultVO;
import org.zen.frame.base.domain.obj.CheckResult;

import java.util.List;

public interface HyPreDateHandler {

    CheckResultVO checkResult = new CheckResultVO();
      void preDateHandler(CheckResult cr, List successDatas, List failDatas, String taskId);

}
