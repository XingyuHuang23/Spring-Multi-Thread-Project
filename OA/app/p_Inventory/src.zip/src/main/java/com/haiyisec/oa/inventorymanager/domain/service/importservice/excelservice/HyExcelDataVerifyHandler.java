package com.haiyisec.oa.inventorymanager.domain.service.importservice.excelservice;

import cn.afterturn.easypoi.excel.entity.result.ExcelVerifyHandlerResult;
import cn.afterturn.easypoi.handler.inter.IExcelVerifyHandler;
import org.apache.poi.ss.formula.functions.T;

import java.util.ArrayList;
import java.util.List;

public interface HyExcelDataVerifyHandler<T> extends IExcelVerifyHandler<T> {
     List  failData = new ArrayList<>();
}
