package com.haiyisec.oa.inventorymanager.domain.service.test;

import com.haiyisec.oa.inventorymanager.domain.model.vo.goods.HyExcelModel;

import java.util.List;

public interface HySuccessHandler {

   void successHandler(List<HyExcelModel> successDatas, String taskId);
}
