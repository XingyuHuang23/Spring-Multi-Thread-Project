package com.haiyisec.oa.inventorymanager.domain.repository;

public interface StatisticRepository {
}
