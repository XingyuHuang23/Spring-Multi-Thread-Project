package com.haiyisec.oa.inventorymanager.domain.service.test;

import cn.afterturn.easypoi.csv.CsvImportUtil;
import cn.afterturn.easypoi.csv.entity.CsvImportParams;
import cn.afterturn.easypoi.excel.ExcelImportUtil;
import cn.afterturn.easypoi.excel.entity.ImportParams;
import cn.afterturn.easypoi.excel.entity.result.ExcelImportResult;
import com.haiyisec.oa.inventorymanager.domain.model.po.goods.CommodityFail;
import com.haiyisec.oa.inventorymanager.domain.model.po.goods.ImportMonitor;
import com.haiyisec.oa.inventorymanager.domain.model.vo.goods.CheckResultVO;
import com.haiyisec.oa.inventorymanager.domain.model.vo.goods.CommodityExcelVerifyVO;
import com.haiyisec.oa.inventorymanager.domain.service.CheckImportService;
import com.haiyisec.oa.inventorymanager.domain.service.CommodityService;
import com.haiyisec.oa.inventorymanager.domain.service.ImportMonitorService;
import com.haiyisec.oa.inventorymanager.domain.service.importservice.CommodityFailService;
import com.haiyisec.oa.inventorymanager.domain.service.importservice.excelservice.CommodityExcelDataHandler;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.zen.frame.base.domain.obj.CheckResult;
import org.zen.frame.base.domain.obj.OutResult;
import org.zen.frame.func.excel.ExcelUtil;
import org.zen.frame.func.threadpool.HyThreadPoolBuilder;
import org.zen.frame.func.threadpool.threadpool.HyRunnable;
import org.zen.frame.func.threadpool.threadpool.HyThreadPoolExecutor;
import org.zen.frame.func.threadpool.threadpool.IThreadPoolTerminated;
import org.zen.frame.util.JsonSpringUtil;
import org.zen.frame.vendor.spring.springmvc.service.ICurUserService;

import javax.servlet.http.HttpServletResponse;
import java.io.*;

import java.text.DecimalFormat;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.RejectedExecutionException;

@Slf4j
@Service
public class HyImport {
    @Autowired
    private ImportMonitorService importMonitorService;

    @Autowired
    private CheckImportService checkImportService;

    @Autowired
    private ICurUserService curUserService; //用来获取loginuserId

    @Autowired
    private CommodityFailService commodityFailService;


    @Autowired
    private CommodityService commodityService;

    private CommodityExcelDataHandler commodityExcelDataHandler = new CommodityExcelDataHandler();
    //只用作导入中的时候用
    private ImportMonitor importMonitor;


    //项目路径
    @Value("${server.tomcat.basedir}")
    private String basedir;

    private String userId = "";
    private Map<String, Object> result = new HashMap();
    private boolean verifyCancelFlag = false;
    private CheckResult cr = new CheckResult();

    private String format;

    public OutResult importData(ImportConfig importConfig) throws Exception {

        OutResult or = new OutResult();
        MultipartFile file = importConfig.getFile();
        String[] excelTitle = importConfig.getTitles();
        String taskId = importConfig.getTaskId();


        HashMap map = new HashMap();
        map.put("taskId", taskId);

        or.setDatas(map);

        //判断能否单模块多导入


//        if (importMonitorService.userWorking(taskId)) {
//            or.setSuccess(false);
//            or.setErrorCode(ErrorCode.导入_任务正在导入_code);
//            or.setMsg(ErrorCode.导入_任务正在导入_msg);
//            return or;
//        }

        if (importConfig.getOperationConfig()!=null && importMonitorService.userWorking(importConfig).isSuccess()) {

          or.setSuccess(false);
          or.setErrorCode(ErrorCode.导入_限定策略_阈值_code);
          or.setMsg(ErrorCode.导入_限定策略_阈值_msg);
          return or;
          }


        //校验表头以及excel文档内部样式
        //@todo： 准备状态
        OutResult or_format = importFileFormatVerify(file, excelTitle);
        if (!or_format.isSuccess()) {

            return or_format;
        }


        prepareWork(importConfig);

        try {
            startCheck(importConfig, taskId, userId);
        } catch (Exception e) {

            importMonitorService.setStatus(taskId, Status.INTERRUPT);
            or.setSuccess(false);
            or.setMsg("物品导入错误");
            return or;
        }

        return or;
    }

    private void prepareWork(ImportConfig importConfig) {

        ImportMonitor importMonitor = new ImportMonitor();
        importMonitor.setTaskId(importConfig.getTaskId());
        importMonitor.setUserId(curUserService.getLoginUserId());
        importMonitor.setModel(importConfig.getModel());

        importMonitorService.createMonitor(importMonitor);
    }


    //导入文件格式校验
    //@todo: 提供外部校验方法 只提供单行表头校验
    //@todo: csv的话有很多编码的校验+
    //@todo: csv能不能只读第一行
    private OutResult importFileFormatVerify(MultipartFile file, String[] list_title) throws Exception {
        List excelTitle = Arrays.asList(list_title);
        OutResult or = new OutResult();
        if (file.getOriginalFilename().endsWith(".xls") || file.getOriginalFilename().endsWith(".xlsx")) {


            ImportParams params = new ImportParams();

            //读取一行，先判断excel表头是否符合规定
            //@todo: 提供表头跟sheet的判断方法
            params.setReadRows(1);
            params.setNeedSave(true);
            ExcelImportResult excelImportResult = null;


            //一次读取,   这里就进行了一次读取，而仅仅只是为了校验表头，觉得不合理
            excelImportResult = ExcelImportUtil.importExcelMore(file.getInputStream(), Map.class, params);


            //判断sheet
            Sheet sheet = excelImportResult.getWorkbook().getSheetAt(0);
            if (excelImportResult.getWorkbook().getNumberOfSheets() > 1 || sheet == null) {

                or.setSuccess(false);
                or.setErrorCode(ErrorCode.导入_文件格式错误_code);
                or.setMsg(ErrorCode.导入_文件格式错误_msg);

                return or;
            }
            //判断表头数量
            List<Map> list = excelImportResult.getList();
            Set<String> titleSet = list.get(0).keySet();

            if (titleSet.size() != excelTitle.size()) {

                or.setSuccess(false);
                or.setErrorCode(ErrorCode.导入_表头错误_code);
                or.setMsg(ErrorCode.导入_表头错误_msg);

                return or;
            }
            //判断表头详情
            for (String titleName : titleSet) {
                if (!excelTitle.contains(titleName)) {
                    or.setSuccess(false);
                    or.setErrorCode(ErrorCode.导入_表头错误_code);
                    or.setMsg(ErrorCode.导入_表头错误_msg);

                    return or;
                }
            }
            format = "excel";


        } else if (file.getOriginalFilename().endsWith(".csv")) {

            //编码判断
            File file_csv = multipartFileToFile(file);
            java.io.InputStream ios = new java.io.FileInputStream(file_csv);
            byte[] b = new byte[3];
            ios.read(b);
            ios.close();

            if (!(b[0] == -17 && b[1] == -69 && b[2] == -65)) {
                or.setSuccess(false);
                or.setErrorCode(ErrorCode.导入_文件编码错误_code);
                or.setMsg(ErrorCode.导入_文件编码错误_msg);

                return or;
            }

            //使用原生获取表头
            BufferedReader br = null;
            try {
                FileReader f = new FileReader(file_csv);
                br = new BufferedReader(f);
                // CSV文件的分隔符
                String DELIMITER = ",";
                // 按行读取
                String line;
                if ((line = br.readLine()) != null) {

                    String[] titleSet = line.split(DELIMITER);


                    if (titleSet.length > 5) {

                        or.setSuccess(false);
                        or.setErrorCode(ErrorCode.导入_表头错误_code);
                        or.setMsg(ErrorCode.导入_表头错误_msg);

                        return or;
                    }
                    for (String titleName : titleSet) {
                        titleName = titleName.replaceAll("\\p{C}", "");
                        if (!excelTitle.contains(titleName)) {
                            or.setSuccess(false);
                            or.setErrorCode(ErrorCode.导入_表头错误_code);
                            or.setMsg(ErrorCode.导入_表头错误_msg);
                            return or;
                        }
                    }
                }
            } finally {
                br.close();
            }
            format = "csv";
        } else {

            or.setSuccess(false);
            or.setErrorCode(ErrorCode.导入_文件格式错误_code);
            or.setMsg(ErrorCode.导入_文件格式错误_msg);
            return or;
        }
        or.setSuccess(true);
        return or;
    }

    //开始导入过程包含：文件数据校验；文件数据导入
    private Map startCheck(ImportConfig importConfig, String taskId, String userId) throws Exception {
        //@todo: 可能不用删数据 上一次的处理过程独立为新的方法
        //@todo:创造ImportMonitor的位置待讨论


        MultipartFile file = importConfig.getFile();
        //初始化监控po的任务id，用户id，任务状态


        Class<?> pojoClass = importConfig.getDataEntity();

        List successDatas = new ArrayList<>();
        List failDatas = new ArrayList<>();
        //单线程的线程池进行文件数据校验过滤
        //@todo: 单线程线程池，可收集任务，进入排队
        //@todo: 修改为spring线程池该业务公用进行排序
        HyThreadPoolExecutor checkPool = new HyThreadPoolBuilder().setPoolName("数据校验线程池-").fiexedBuild(1);
        importMonitorService.setCheckPool(taskId, checkPool);

        File tmpFile = null;
        try {
            //文件复制
            tmpFile = new File(basedir + "/excel/" + UUID.randomUUID());
            final File newFile = tmpFile;
            FileUtils.copyInputStreamToFile(file.getInputStream(), newFile);
            HyRunnable importVerify = new HyRunnable("000") {
                //            @SneakyThrows
                @Override
                public void run() {

                    successDatas.clear();
                    failDatas.clear();
                    importConfig.getHyExcelDataVerifyHandler().failData.clear();

                    try {
                        //校验开始，初始化标志位
                        //@todo: 中断标识应该放在po内部判断 中断标志位
                        log.info("校验开始...................");
                        verifyCancelFlag = false;


                        if (format.equals("excel")) {
                            ImportParams params = new ImportParams();
                            params.setHeadRows(1);
                            params.setNeedVerify(true);

                            if (importConfig.getHyExcelDataHandler() != null) {
                                params.setDataHandler(importConfig.getHyExcelDataHandler());
                            }

                            if (importConfig.getHyExcelDataVerifyHandler() != null) {
                                params.setVerifyHandler(importConfig.getHyExcelDataVerifyHandler());
                            }


                            ExcelImportResult excelImportResult = null;

                            try (FileInputStream fis = new FileInputStream(newFile)) {
                                //二次读取
                                excelImportResult = ExcelImportUtil.importExcelMore(fis, pojoClass, params);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                            successDatas.addAll(excelImportResult.getList());
                            failDatas.addAll(excelImportResult.getFailList());

                        } else if (format.equals("csv")) {


                            CsvImportParams params_csv = new CsvImportParams();
                            params_csv.setTitleRows(0);
                            params_csv.setHeadRows(1);
                            params_csv.setNeedVerify(true);
                            if (importConfig.getHyExcelDataHandler() != null) {
                                params_csv.setDataHandler(importConfig.getHyExcelDataHandler());
                            }

                            if (importConfig.getHyExcelDataVerifyHandler() != null) {
                                params_csv.setVerifyHandler(importConfig.getHyExcelDataVerifyHandler());
                            }

                            List result = null;

                            try (FileInputStream fis = new FileInputStream(newFile)) {
                                result = CsvImportUtil.importCsv(fis, pojoClass, params_csv);
                                //csv需要在verify过程中加入failData
                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                            successDatas.addAll(result);
                            failDatas.addAll(importConfig.getHyExcelDataVerifyHandler().failData);
                        }


                        importMonitorService.setTotalNum(taskId, successDatas.size() + failDatas.size());
                        importMonitorService.setCheckFailNum(taskId, failDatas.size());

                        if (Thread.currentThread().isInterrupted()) {
                            importMonitorService.setInterrupted(taskId);
                        }

                    } finally {
                        if (newFile.exists()) {
                            newFile.delete();
                        }
                    }
                }
            };

            checkPool.setiThreadPoolTerminated(new IThreadPoolTerminated() {
                @Override
                public void terminated() {

                    if (!importMonitorService.isInterrupted(taskId) && successDatas != null && successDatas.size() > 0) {


                        if (importConfig.getHyAdaption() instanceof HyPreDateHandler) {
                            importConfig.getHyAdaption().preDateHandler(cr, successDatas, failDatas, taskId);
                        }

                        if (importConfig.getHyAdaption() instanceof HyFailHandler) {
                            importConfig.getHyAdaption().failHandler(failDatas, importConfig.getTaskId());
                        }
                    } else {
                        cr.setSuccess(false);
                        cr.getErrorMsg().append("导入文件的数据全部校验不通过，请检查后重新导入！");
                        importMonitorService.finished(taskId);
                        return;
                    }

                    result.put("userId", userId);
                    result.put("taskId", taskId);
                    result.put("successData", successDatas);
                    result.put("failData", failDatas);

                    excelImportDatas(result, importConfig);


                }
            });


            importMonitorService.setStatus(taskId, Status.CHECK);
            checkPool.submit(importVerify);

            return result;
        } catch (Exception e) {
            if (tmpFile != null && tmpFile.exists()) {
                tmpFile.delete();
            }
        } finally {
            checkPool.shutdown();
        }
        //@todo: importMonitor记录中断原因
        return null;
    }


    //下面两个方法是Mutipart转File
    public File multipartFileToFile(MultipartFile file) throws Exception {

        File toFile = null;
        if (file.equals("") || file.getSize() <= 0) {
            file = null;
        } else {
            InputStream ins = null;
            ins = file.getInputStream();
            toFile = new File(file.getOriginalFilename());
            inputStreamToFile(ins, toFile);
            ins.close();
        }
        return toFile;
    }

    private void inputStreamToFile(InputStream ins, File file) throws Exception {
        try {
            OutputStream os = new FileOutputStream(file);
            int bytesRead = 0;
            byte[] buffer = new byte[8192];
            while ((bytesRead = ins.read(buffer, 0, 8192)) != -1) {
                os.write(buffer, 0, bytesRead);
            }
            os.close();
            ins.close();
        } finally {

        }
    }


    public CommodityFail toCommodityFail(CommodityExcelVerifyVO commodityExcelVerifyVO, String taskId) {
        CommodityFail commodityFail = new CommodityFail();
        commodityFail.setName(commodityExcelVerifyVO.getName());
        commodityFail.setType(commodityExcelVerifyVO.getType());
        commodityFail.setPosition(commodityExcelVerifyVO.getPosition());
        commodityFail.setStoreId("000");
        commodityFail.setUnit(commodityExcelVerifyVO.getUnit());
        commodityFail.setCommodityNo(commodityExcelVerifyVO.getCommodityNo());
//        commodityFail.setFailReason("导入文件第 " + commodityExcelVerifyVO.getRowNum() + " 行导入失败:" + commodityExcelVerifyVO.getErrorMsg());
        commodityFail.setFailReason(commodityExcelVerifyVO.getErrorMsg());
        commodityFail.setImportMonitorId("check");
        commodityFail.setTaskId(taskId);

        return commodityFail;
    }


    public void cancelTask(String taskId) {

        importMonitorService.interrupt(taskId);

    }

    public void excelImportDatas(Map result, ImportConfig importConfig) {

        CheckResultVO crvo = (CheckResultVO) result.get("result");

        List success_list = (List) result.get("successData"); //获取通过了check的数据
        String taskId = result.get("taskId").toString();


        HyThreadPoolExecutor datasImportPool = new HyThreadPoolBuilder().setPoolName("数据导入线程池-").setCoreSize(1).build();

        importMonitorService.setImportPool(taskId, datasImportPool);


        //根据200个进行切割
        int threadDataNum = 200;


        if (success_list.size() > threadDataNum) {
            int x = success_list.size() / threadDataNum;
            //开启n个线程
            for (int y = 0; y < x + 1; y++) {
                int endNum = (threadDataNum * (y + 1)) < success_list.size() ? (threadDataNum * (y + 1)) : success_list.size();
                importDatasByThreadPool(success_list.subList(threadDataNum * y, endNum),  String.valueOf(y), datasImportPool, importConfig);
            }
        } else {
            //小于200开启单线程
            importDatasByThreadPool(success_list,"0", datasImportPool, importConfig);
        }


        //线程池关闭后续处理逻辑
        datasImportPool.setiThreadPoolTerminated(new IThreadPoolTerminated() {
            @SneakyThrows
            @Override
            public void terminated() {


                if (!importMonitorService.isInterrupted(taskId)) {
                    importMonitorService.finished(taskId);
                }

            }
        });
        //关闭线程池提交任务
        datasImportPool.shutdown();
    }

    private void importDatasByThreadPool(List success_list,  String id, HyThreadPoolExecutor datasImportPool, ImportConfig importConfig) {

        HyRunnable taskRunnable = new HyRunnable(id) {
            @Override
            public void run() {

                if (importConfig.getHyAdaption() instanceof HySuccessHandler) {
                    importConfig.getHyAdaption().successHandler(success_list, importConfig.getTaskId());
                }
                //importConfig.getHyImportAdaption().importData(list,importConfig.getTaskId());

            }
        };

        try {

            importMonitorService.setStatus(importConfig.getTaskId(), Status.WORK);//执行导入runnable
            datasImportPool.submit(taskRunnable);

        } catch (RejectedExecutionException e) {
            log.info("第： " + id + " 个任务提交被拒绝，超过线程池容量。");
        }
    }


    public String getProgressRateResult(String taskId) {
        String str = "";

        if (taskId.equals("1")) {
            ImportMonitor newImportMonitor = new ImportMonitor();
            newImportMonitor.setTaskStatus(Status.NONE);
            str = JsonSpringUtil.obj2Json(newImportMonitor);
            str = "data: " + str + "\n\n";
            return str;
        }
        //数据库实例
        ImportMonitor importMonitor = null;
        //缓存
        ImportMonitor cacheMonitor;


        DecimalFormat df = new DecimalFormat("0");


        cacheMonitor = importMonitorService.getImportMonitor(taskId);

        importMonitor = importMonitorService.queryOneByTaskId(taskId);

        ConcurrentHashMap l = importMonitorService.getCacheList();

        if (cacheMonitor != null) {
            //存在正在导入任务
            float progress;
            if (cacheMonitor.getTotalNum() == 0) {
                progress = 0;
            } else {
                progress = (float) (cacheMonitor.getCheckFailNum() + cacheMonitor.getFailNumRealTime().get() + cacheMonitor.getSuccessNumRealTime().get()) / cacheMonitor.getTotalNum() * 100;
            }

            cacheMonitor.setProgressRate(df.format(progress));

            cacheMonitor.setImportFailNum(cacheMonitor.getFailNumRealTime().get());
            cacheMonitor.setSuccessNum(cacheMonitor.getSuccessNumRealTime().get());
            cacheMonitor.setProgressRate(df.format(progress));
            //sse每访问一次进行一次成功/失败数的更新
            importMonitorService.save(cacheMonitor);

            str = JsonSpringUtil.obj2Json(cacheMonitor);
        } else if (importMonitor != null) {
            //关机-重启  展示上次导入情况
            importMonitor.getSuccessNumRealTime().getAndAdd(importMonitor.getSuccessNum());
            importMonitor.getFailNumRealTime().getAndAdd(importMonitor.getImportFailNum());
            float progress = (float) (importMonitor.getCheckFailNum() + importMonitor.getFailNumRealTime().get() + importMonitor.getSuccessNumRealTime().get()) / importMonitor.getTotalNum() * 100;

            importMonitor.setProgressRate(df.format(progress));
            str = JsonSpringUtil.obj2Json(importMonitor);
        }

        str = "data: " + str + "\n\n";
        return str;

    }

    //下载错误文件
    public void downloadErrorDatas(HttpServletResponse response, String taskId) throws Exception {

        //获取旧的导入批次
        List<CommodityFail> errorDatas = commodityFailService.getErrorDatas(taskId);


        ExcelUtil.downExcel(response, "errorDatas", errorDatas, CommodityFail.class);
    }
}
