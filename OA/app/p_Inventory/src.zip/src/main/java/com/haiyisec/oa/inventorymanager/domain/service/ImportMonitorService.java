package com.haiyisec.oa.inventorymanager.domain.service;

import com.haiyisec.oa.inventorymanager.domain.model.po.goods.ImportMonitor;
import com.haiyisec.oa.inventorymanager.domain.repository.ImportMonitorRepository;
import com.haiyisec.oa.inventorymanager.domain.service.test.ImportConfig;
import com.haiyisec.oa.inventorymanager.domain.service.test.Status;
import com.haiyisec.oa.inventorymanager.domain.service.test.test_strategy.StrategyType;
import com.haiyisec.oa.inventorymanager.domain.service.test.test_strategy.SysImportStrategy;
import com.haiyisec.oa.inventorymanager.domain.service.test.test_strategy.Strategy;
import com.haiyisec.oa.inventorymanager.domain.service.test.test_strategy.UserImportStrategy;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.zen.frame.base.domain.obj.OutResult;
import org.zen.frame.func.threadpool.threadpool.HyThreadPoolExecutor;
import org.zen.frame.vendor.spring.springmvc.service.CurUserService;

import javax.annotation.PostConstruct;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class ImportMonitorService  {
    //这里专门使用ImMonitor
    @Autowired
    private ImportMonitorRepository importMonitorRepository;


    @Autowired
    private SysImportStrategy sysImportStrategy;
    @Autowired
    private UserImportStrategy userImportStrategy;

    private ConcurrentHashMap<String, ImportMonitor> list_importMonitor = new ConcurrentHashMap<>();

    public  ConcurrentHashMap<String, HyThreadPoolExecutor> importDataPool = new ConcurrentHashMap<>();

    public  ConcurrentHashMap<String, HyThreadPoolExecutor> checkDataPool = new ConcurrentHashMap<>();

    @PostConstruct
    public void init(){
        //系统重启之后改变状态
        List<ImportMonitor> pre_importMonitor = importMonitorRepository.findByTaskStatus(Status.WORK);
        List<ImportMonitor> pre_importMonitor_check = importMonitorRepository.findByTaskStatus(Status.CHECK);

        if(pre_importMonitor!=null && pre_importMonitor.size()>0){
            for(ImportMonitor im:pre_importMonitor){
                im.setTaskStatus(Status.ERROR);
                importMonitorRepository.save(im);
            }
        }

        if(pre_importMonitor!=null && pre_importMonitor_check.size()>0){
            for(ImportMonitor im:pre_importMonitor_check){
                im.setTaskStatus(Status.ERROR);
                importMonitorRepository.save(im);
            }
        }
    }

    public ImportMonitor queryOneByAccountId(String accountId){
        return importMonitorRepository.findByUserId(accountId);
    }


    public ImportMonitor queryOneByTaskId(String taskId){
        return importMonitorRepository.findByTaskId(taskId);
    }

    public void save(ImportMonitor importMonitor){
        importMonitorRepository.save(importMonitor);
    }

    public void delOldImportMonitor(ImportMonitor importMonitor){
        importMonitorRepository.delete(importMonitor);
    }


    public void createMonitor(ImportMonitor importMonitor){

        list_importMonitor.put(importMonitor.getTaskId(), importMonitor);

        save(importMonitor);
    }

    public void setStatus(String taskId, Status status){

        ImportMonitor importMonitor = list_importMonitor.get(taskId);
        importMonitor.setTaskStatus(status);

        save(importMonitor);
    }

    public  ImportMonitor getImportMonitor(String taskId) {

          return   list_importMonitor.get(taskId);
    }

//    public boolean userWorking(String taskId) {
//        if(importMonitorRepository.countByTaskStatus(Status.WORK)>0){   //独占
//            return true;
//        }
//        if(importMonitorRepository.countByTaskId(taskId)>0){   //整个系统只能一个
//            return true;
//        }
//
//        if(importMonitorRepository.countByTaskIdAndUserId(taskId,curUserService.getLoginUserId())>0){  //同个用户只能一个
//            return true;
//        }
//
//       return false;
//    }

    public OutResult userWorking(ImportConfig importConfig) {
        OutResult or = new OutResult();

        if(importConfig.getOperationConfig().getStrategyType() == StrategyType.APP){
            return appTypeWorking(importConfig);
        }

        if(importConfig.getOperationConfig().getStrategyType() == StrategyType.USER){
            return  userTypeWorking(importConfig);
        }

        if(importConfig.getOperationConfig().getStrategyType() == StrategyType.CUSTOM){
            return  customTypeWorking(importConfig);
        }

        return or;
    }

    private OutResult customTypeWorking(ImportConfig importConfig) {

        Strategy cs = importConfig.getOperationConfig().getCustomStrategy();

        if(cs instanceof SysImportStrategy){
            return   appTypeWorking(importConfig);
        }

        if(cs instanceof UserImportStrategy){
            return   userTypeWorking(importConfig);
        }
        return null;
    }


    private OutResult userTypeWorking(ImportConfig importConfig) {
        UserImportStrategy.ImportParams ip = (UserImportStrategy.ImportParams)importConfig.getOperationConfig().getImportParams();

        ip.setUserTaskNum(getModelUserTaskNum(importConfig.getModel(),ip.getUserId()));

        OutResult  or = userImportStrategy.operation(ip);
        return or;
    }


    private OutResult appTypeWorking(ImportConfig importConfig) {

        int maxTaskNum = (int)importConfig.getOperationConfig().getImportParams();
        SysImportStrategy.ImportParams ip = new SysImportStrategy.ImportParams().setMaxTaskNum(maxTaskNum);

        ip.setModelTaskNum(getModelTaskNum(importConfig.getModel()));

        OutResult or  = sysImportStrategy.operation(ip);
        return or;
    }



    public void successNumRealTime(String taskId){

        ImportMonitor importMonitor = list_importMonitor.get(taskId);

        importMonitor.getSuccessNumRealTime().getAndIncrement();
    }

    public void failNumRealTime(String taskId) {

        ImportMonitor importMonitor = list_importMonitor.get(taskId);

        importMonitor.getFailNumRealTime().getAndIncrement();

    }

    public void finished(String taskId) {

        ImportMonitor importMonitor = list_importMonitor.get(taskId);

        importMonitor.setSuccessNum(importMonitor.getSuccessNumRealTime().get());
        importMonitor.setImportFailNum(importMonitor.getFailNumRealTime().get());
        importMonitor.setFinishTime(new DateTime());
        importMonitor.setTaskStatus(Status.FINISH);
        save(importMonitor);

        list_importMonitor.remove(taskId);
    }

    public void setStartTime(String taskId) {

        ImportMonitor importMonitor = list_importMonitor.get(taskId);

        importMonitor.setStartTime(new DateTime());
        save(importMonitor);
    }




    public void setTotalNum(String taskId, int total) {

        ImportMonitor importMonitor = list_importMonitor.get(taskId);
        importMonitor.setTotalNum(total);
       save(importMonitor);
    }


    public void setCheckFailNum(String taskId, int size) {

        ImportMonitor importMonitor = list_importMonitor.get(taskId);
        importMonitor.setCheckFailNum(size);
        save(importMonitor);
    }



    public void setImportPool(String taskId, HyThreadPoolExecutor datasImportPool) {

        importDataPool.put(taskId, datasImportPool);

    }

    public HyThreadPoolExecutor getImportPool(String taskId) {

        return importDataPool.get(taskId);
    }

    public void interrupt(String taskId) {

        HyThreadPoolExecutor datasCheckPool = getCheckPool(taskId);

        HyThreadPoolExecutor datasImportPool = getImportPool(taskId);


        if(datasCheckPool!=null){

            checkDataPool.remove(taskId);
            datasCheckPool.cancelAllTask();

        }

        if (datasImportPool!= null) {

            ImportMonitor importMonitor = list_importMonitor.get(taskId);
            importMonitor.setFinishTime(new DateTime());
            importMonitor.setTaskStatus(Status.INTERRUPT);

            save(importMonitor);

            datasImportPool.cancelAllTask();
        }

        list_importMonitor.remove(taskId);
    }



    public void setInterrupted(String taskId) {

        ImportMonitor importMonitor = list_importMonitor.get(taskId);
        importMonitor.setInterrupt(true);
        importMonitor.setTaskStatus(Status.INTERRUPT);

        save(importMonitor);
        list_importMonitor.remove(taskId);
    }

    public boolean isInterrupted(String taskId) {

        if(list_importMonitor.get(taskId)==null){
            return true;
        }
       return false;
    }

    public void setCheckPool(String taskId, HyThreadPoolExecutor checkPool) {
                checkDataPool.put(taskId,checkPool);
    }

    public HyThreadPoolExecutor getCheckPool(String taskId) {
        return   checkDataPool.get(taskId);
    }

    public ConcurrentHashMap getCacheList() {
        return list_importMonitor;
    }

    public int getModelTaskNum(String model) {
       return  importMonitorRepository.countByModelAndTaskStatus(model,Status.CHECK).intValue()+
               importMonitorRepository.countByModelAndTaskStatus(model,Status.WORK).intValue();
    }

    public int getModelUserTaskNum(String model,String userId) {
        return    importMonitorRepository.countByModelAndUserIdAndTaskStatus(model,userId,Status.CHECK).intValue()+
                   importMonitorRepository.countByModelAndUserIdAndTaskStatus(model,userId,Status.WORK).intValue();
    }
}
