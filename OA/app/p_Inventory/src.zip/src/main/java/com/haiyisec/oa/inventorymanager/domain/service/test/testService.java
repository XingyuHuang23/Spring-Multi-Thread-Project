package com.haiyisec.oa.inventorymanager.domain.service.test;

import com.haiyisec.oa.inventorymanager.domain.model.vo.goods.CommodityExcelVerifyVO;
import com.haiyisec.oa.inventorymanager.domain.service.importservice.excelservice.CommodityExcelDataHandler2;
import com.haiyisec.oa.inventorymanager.domain.service.importservice.excelservice.CommodityExcelDataVerifyHandler2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.zen.frame.base.domain.obj.OutResult;

import java.util.ArrayList;
import java.util.List;

@Service
public class testService {

    @Autowired
    HyImport hyImport;
    @Autowired
    HyAdaption ca;

    public OutResult test(MultipartFile file,String taskId) throws Exception{
        String[] excelTitles = {"物品名称","物品类别","物品单位","所属位置","位置编号"};

        //@todo：还是要变为string[]
//                String importMonitorId = importservice.importDatas(cr, file, excelTitles);
//
        CommodityExcelDataHandler2 d = new CommodityExcelDataHandler2();
        d.setNeedHandlerFields(new String[]{"物品类别", "所属位置"});

        CommodityExcelDataVerifyHandler2 v = new CommodityExcelDataVerifyHandler2();


        ImportConfig importConfig = new ImportConfig("物品导入", file, excelTitles, CommodityExcelVerifyVO.class, ca);
        importConfig.setHyExcelDataVerifyHandler(v);
        importConfig.setHyExcelDataHandler(d);
        OutResult or2 = hyImport.importData(importConfig);

        return or2;
    }


}
