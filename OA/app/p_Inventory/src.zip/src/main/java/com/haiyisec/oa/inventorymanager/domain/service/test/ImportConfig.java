package com.haiyisec.oa.inventorymanager.domain.service.test;

import com.haiyisec.oa.inventorymanager.domain.service.importservice.excelservice.HyExcelDataHandler;
import com.haiyisec.oa.inventorymanager.domain.service.importservice.excelservice.HyExcelDataVerifyHandler;
import com.haiyisec.oa.inventorymanager.domain.service.test.test_strategy.OperationConfig;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.UUID;

@Getter
@Setter
@Accessors(chain = true)
public class ImportConfig {

    public ImportConfig() {

    }

    public ImportConfig(String model,MultipartFile file,String[] titles,Class<?> dataEntity,HyAdaption hyAdaption) {
        this.file = file;
        this.titles = titles;
        this.dataEntity = dataEntity;
        this.hyAdaption = hyAdaption;
        this.model = model;
    }

    //表头
    private String[] titles;
    //导入任务名称
    private String taskId = String.valueOf(UUID.randomUUID());
    //文件
    private MultipartFile file;
    //能否单业务多导入
    private boolean multiImport;

    private HyExcelDataHandler hyExcelDataHandler;
    private HyExcelDataVerifyHandler hyExcelDataVerifyHandler;
    private Class<?> dataEntity;

   private HyAdaption hyAdaption;
   //业务名
   private String model;

   private OperationConfig operationConfig;

}
