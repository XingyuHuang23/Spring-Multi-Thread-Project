package com.haiyisec.oa.inventorymanager.domain.service.test;

import com.haiyisec.oa.inventorymanager.domain.model.vo.goods.HyExcelModel;

import java.util.List;

public interface HyFailHandler {

     void failHandler(List<HyExcelModel> failDatas, String taskId);

}
