package com.haiyisec.oa.inventorymanager.domain.model.vo.goods;

import cn.afterturn.easypoi.handler.inter.IExcelDataModel;
import cn.afterturn.easypoi.handler.inter.IExcelModel;

public  interface HyExcelModel extends IExcelModel,IExcelDataModel {

}
