package com.haiyisec.oa.inventorymanager.domain.service.test;

import com.haiyisec.oa.inventorymanager.domain.model.vo.goods.CheckResultVO;
import com.haiyisec.oa.inventorymanager.domain.model.vo.goods.HyExcelModel;
import org.apache.poi.ss.formula.functions.T;
import org.springframework.stereotype.Component;
import org.zen.frame.base.domain.obj.CheckResult;

import java.util.List;

public interface HyImportAdaption {

    public CheckResultVO checkResult = new CheckResultVO();
    public  void checkTerminate(CheckResult cr, List successDatas, List failDatas,String taskId);

    public  void importData(List<HyExcelModel> successDatas,String taskId);
    public  void importTerminate();

}
