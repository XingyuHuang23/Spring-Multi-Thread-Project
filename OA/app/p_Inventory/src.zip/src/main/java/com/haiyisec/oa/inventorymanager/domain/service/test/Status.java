package com.haiyisec.oa.inventorymanager.domain.service.test;

public enum Status {
    CHECK,WORK,FINISH,INTERRUPT,ERROR,NONE
}
